from __future__ import division
import numpy as np
from scipy import integrate
from model_hh_interval import model_hh
from impulse_t_interval import impulse_t
from plot_hh import plot_hh

pars = {}
pars['gKbar'] = 36
pars['gNabar'] = 120
pars['gL'] = 0.3
pars['EK'] = -12
pars['ENa'] = 115
pars['EL'] = 10.6
pars['C'] = 1

pars['alphan'] = lambda V: 0.01*(10 - V)/(np.exp(1 - V/10) - 1)
pars['betan'] = lambda V: 0.125 * np.exp(-V / 80)
pars['alpham'] = lambda V: 0.1*(25 - V)/(np.exp(2.5 - V/10) - 1)
pars['betam'] = lambda V: 4 * np.exp(-V / 18)
pars['alphah'] = lambda V: 0.07 * np.exp(-V / 20)
pars['betah'] = lambda V: 1 / (np.exp(3 - V/10) + 1)

pars['V0'] = 0
Vrest = pars['V0']
pars['n0'] = pars['alphan'](Vrest) / (pars['alphan'](Vrest) + pars['betan'](Vrest))
pars['m0'] = pars['alpham'](Vrest) / (pars['alpham'](Vrest) + pars['betam'](Vrest))
pars['h0'] = pars['alphah'](Vrest) / (pars['alphah'](Vrest) + pars['betah'](Vrest))

t0, tf, tstep = 0, 40, 0.02
t = np.arange(t0, tf + tstep, tstep)
y0 = np.array([pars['V0'], pars['n0'], pars['m0'], pars['h0']])

y = integrate.odeint(model_hh, y0, t, args=(pars,))

dyn = {}
dyn['t'] = t
dyn['V'] = y[:, 0]
dyn['n'] = y[:, 1]
dyn['m'] = y[:, 2]
dyn['h'] = y[:, 3]
dyn['gK'] = pars['gKbar'] * dyn['n']**4
dyn['gNa'] = pars['gNabar'] * dyn['m']**3 * dyn['h']
dyn['gL'] = pars['gL'] * np.ones(len(dyn['t']))
dyn['IK'] = dyn['gK'] * (dyn['V'] - pars['EK'])
dyn['INa'] = dyn['gNa'] * (dyn['V'] - pars['ENa'])
dyn['IL'] = dyn['gL'] * (dyn['V'] - pars['EL'])
dyn['appliedI'] = impulse_t(dyn['t'])

plot_hh(dyn, pars)
