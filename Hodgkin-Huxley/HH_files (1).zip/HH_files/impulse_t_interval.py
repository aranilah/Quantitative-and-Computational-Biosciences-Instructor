# -*- coding: utf-8 -*-
"""
Impulse function for two pulses with variable interval.
"""

import numpy as np

I_amp = 20      # Default amplitude
interval = 8.0  # Default time between pulses

def impulse_t(t):
    if isinstance(t, float) or isinstance(t, int):
        if 2 <= t < 2.5:
            return I_amp
        elif (2 + interval) <= t < (2.5 + interval):
            return I_amp
        else:
            return 0
    else:
        I = np.zeros(len(t))
        for i in range(len(t)):
            if 2 <= t[i] < 2.5:
                I[i] = I_amp
            elif (2 + interval) <= t[i] < (2.5 + interval):
                I[i] = I_amp
        return I
