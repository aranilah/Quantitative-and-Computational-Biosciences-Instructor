# impulse_t_threshold.py
import numpy as np

I_amp = 0  # This will be updated externally

def impulse_t(t):
    if isinstance(t, float) or isinstance(t, int):
        return I_amp if 2 <= t < 2.5 else 0
    else:
        I = np.zeros(len(t))
        for i in range(len(t)):
            if 2 <= t[i] < 2.5:
                I[i] = I_amp
        return I
