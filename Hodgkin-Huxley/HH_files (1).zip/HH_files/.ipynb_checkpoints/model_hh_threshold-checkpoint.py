from impulse_t_threshold import impulse_t
import numpy as np

def model_hh(y, t, pars):
    V, n, m, h = y
    I = impulse_t(t)
    Vdot = (1/pars['C']) * (I - pars['gKbar'] * n**4 * (V - pars['EK']) -
                            pars['gNabar'] * m**3 * h * (V - pars['ENa']) -
                            pars['gL'] * (V - pars['EL']))

    if abs(V - 10) < 1e-6:
        ndot = 0.1 * (1 - n) - pars['betan'](V) * n
    else:
        ndot = pars['alphan'](V) * (1 - n) - pars['betan'](V) * n

    if abs(V - 25) < 1e-6:
        mdot = 1.0 * (1 - m) - pars['betam'](V) * m
    else:
        mdot = pars['alpham'](V) * (1 - m) - pars['betam'](V) * m

    hdot = pars['alphah'](V) * (1 - h) - pars['betah'](V) * h
    return np.array([Vdot, ndot, mdot, hdot])
