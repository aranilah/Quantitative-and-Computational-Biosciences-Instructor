# -*- coding: utf-8 -*-
"""
Here, the code serves double duty. If there is only a single value of t, as in the numerical integration, then only a
single applied current value will be returned. However, if many values are input, then the code will return the entire
function, this is useful for plotting and storing the applied current along with the output.

"""
import numpy as np

# impulse_t 
def impulse_t(t):
    '''
    function I = impulse_t(t)
    
    specifies the appplied time-varying current
    works if t is a single value or many values
    '''
    
    if isinstance(t,float):
        if t>2 and t<2.5:
            I=2
        elif t>10 and t<10.5:
            I=25
        else:
            I=0
    else:
        I=np.zeros(len(t))
        for i in range(len(t)):
            if t[i]>2 and t[i]<2.5:
                I[i] = 2
            elif t[i]>10 and t[i]<10.5:
                I[i] = 25
            else:
                I[i]=0
    return I