import numpy as np

I_amp = 15  # Applied current amplitude in µA/cm²
interval = 30  # Interval between pulses in ms

def impulse_t(t):
    """
    Returns two short current pulses:
    - First pulse: 2 to 2.5 ms
    - Second pulse: (2 + interval) to (2.5 + interval) ms
    """
    if isinstance(t, float) or isinstance(t, int):
        if 2 <= t < 2.5 or (2 + interval) <= t < (2.5 + interval):
            return I_amp
        else:
            return 0
    else:
        I = np.zeros_like(t)
        for i in range(len(t)):
            if 2 <= t[i] < 2.5 or (2 + interval) <= t[i] < (2.5 + interval):
                I[i] = I_amp
        return I
