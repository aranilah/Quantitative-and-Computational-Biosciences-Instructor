# master_hh_thresh.py

from __future__ import division
import numpy as np
import matplotlib.pyplot as plt
from scipy.integrate import odeint
from impulse_t_thresh import impulse_t, I_amp
import impulse_t_thresh
from model_hh_thresh import model_hh

# HH Parameters
pars = {
    'gKbar': 36, 'gNabar': 120, 'gL': 0.3,
    'EK': -12, 'ENa': 115, 'EL': 10.6, 'C': 1
}
pars['alphan'] = lambda V: 0.01*(10 - V)/(np.exp(1 - V/10) - 1)
pars['betan'] = lambda V: 0.125 * np.exp(-V / 80)
pars['alpham'] = lambda V: 0.1*(25 - V)/(np.exp(2.5 - V/10) - 1)
pars['betam'] = lambda V: 4 * np.exp(-V / 18)
pars['alphah'] = lambda V: 0.07 * np.exp(-V / 20)
pars['betah'] = lambda V: 1 / (np.exp(3 - V/10) + 1)

# Initial conditions
pars['V0'] = 0
Vrest = pars['V0']
pars['n0'] = pars['alphan'](Vrest) / (pars['alphan'](Vrest) + pars['betan'](Vrest))
pars['m0'] = pars['alpham'](Vrest) / (pars['alpham'](Vrest) + pars['betam'](Vrest))
pars['h0'] = pars['alphah'](Vrest) / (pars['alphah'](Vrest) + pars['betah'](Vrest))

t0, tf, tstep = 0, 20, 0.02
t = np.arange(t0, tf + tstep, tstep)
y0 = np.array([pars['V0'], pars['n0'], pars['m0'], pars['h0']])

# Manually test I_amp values
I_values = [10,11,12, 13, 14]
for I in I_values:
    impulse_t_thresh.I_amp = I
    y = odeint(model_hh, y0, t, args=(pars,))
    V_trace = y[:, 0]

    # Plot
    plt.figure(figsize=(7, 4))
    plt.plot(t, V_trace, 'k', label=f'I = {I} µA/cm²')
    plt.ylim([-20, 150])
    plt.xlabel("Time (ms)")
    plt.ylabel("Membrane Voltage (mV)")
    plt.title(f"HH Neuron Response: I = {I} µA/cm²")
    plt.legend()
    plt.grid(True)
    plt.tight_layout()
    plt.show()
