# -*- coding: utf-8 -*-
"""
Modified impulse_t.py for constant current sweep.
"""


# -*- coding: utf-8 -*-
"""
Impulse function with external control of pulse amplitude.
Applies current only between 2 ms and 2.5 ms.
"""

import numpy as np

I_amp = 0  # Will be set dynamically from master_hh_const.py

def impulse_t(t):
    if isinstance(t, float) or isinstance(t, int):
        return I_amp if 2 <= t < 2.5 else 0
    else:
        I = np.zeros(len(t))
        for i in range(len(t)):
            if 2 <= t[i] < 2.5:
                I[i] = I_amp
        return I
