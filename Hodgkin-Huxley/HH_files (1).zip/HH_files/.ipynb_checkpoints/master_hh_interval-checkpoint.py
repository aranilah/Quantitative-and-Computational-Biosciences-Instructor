# -*- coding: utf-8 -*-
"""
Sweep time interval between two pulses to find minimum required interval for second spike.
"""

from __future__ import division
import numpy as np
from scipy import integrate
from model_hh_const import model_hh
import impulse_t_interval as impulse_t
import matplotlib.pyplot as plt

# HH Parameters
pars = {
    'gKbar': 36,
    'gNabar': 120,
    'gL': 0.3,
    'EK': -12,
    'ENa': 115,
    'EL': 10.6,
    'C': 1
}
pars['alphan'] = lambda V: 0.01*(10 - V)/(np.exp(1 - V/10) - 1)
pars['betan'] = lambda V: 0.125 * np.exp(-V / 80)
pars['alpham'] = lambda V: 0.1*(25 - V)/(np.exp(2.5 - V/10) - 1)
pars['betam'] = lambda V: 4 * np.exp(-V / 18)
pars['alphah'] = lambda V: 0.07 * np.exp(-V / 20)
pars['betah'] = lambda V: 1 / (np.exp(3 - V/10) + 1)

# Initial conditions at equilibrium
Vrest = 0
pars['V0'] = Vrest
pars['n0'] = pars['alphan'](Vrest) / (pars['alphan'](Vrest) + pars['betan'](Vrest))
pars['m0'] = pars['alpham'](Vrest) / (pars['alpham'](Vrest) + pars['betam'](Vrest))
pars['h0'] = pars['alphah'](Vrest) / (pars['alphah'](Vrest) + pars['betah'](Vrest))

# Time vector
t0, tf, tstep = 0, 40, 0.02
t = np.arange(t0, tf + tstep, tstep)
y0 = np.array([pars['V0'], pars['n0'], pars['m0'], pars['h0']])

# Sweep intervals to detect 2nd spike
intervals = np.arange(1.0, 35.1, 0.5)
spike_results = []

for inter in intervals:
    impulse_t.interval = inter
    y = integrate.odeint(model_hh, y0, t, args=(pars,))
    V = y[:, 0]

    # Detect peaks above threshold
    spike_times = t[V > 50]
    spikes = []
    if len(spike_times) > 0:
        spikes.append(spike_times[0])
        for i in range(1, len(spike_times)):
            if spike_times[i] - spike_times[i-1] > 2:
                spikes.append(spike_times[i])

    spike_results.append((inter, len(spikes)))

    # Plot sample traces
    if inter in [10, 30, 50]:
        plt.figure(figsize=(8, 4))
        plt.plot(t, V, label=f'Interval = {inter} ms')
        plt.axhline(50, color='gray', linestyle='--', linewidth=1)
        plt.xlabel("Time (ms)")
        plt.ylabel("Membrane Voltage (mV)")
        plt.title(f'Membrane Potential with Interval = {inter} ms')
        plt.legend()
        plt.grid(True)
        plt.tight_layout()
        plt.show()

# Print threshold interval
for inter, num_spikes in spike_results:
    if num_spikes >= 2:
        print(f"✅ Minimum interval for second spike: {inter} ms")
        break
