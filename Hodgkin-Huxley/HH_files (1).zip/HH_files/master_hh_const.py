# -*- coding: utf-8 -*-
"""
Sweep constant pulse amplitude using impulse_t_const and simulate HH model.
"""

from __future__ import division
import numpy as np
from scipy import integrate
from model_hh_const import model_hh
import impulse_t_const as impulse_t
import matplotlib.pyplot as plt

# --- HH Parameters ---
pars = {}
pars['gKbar'] = 36
pars['gNabar'] = 120
pars['gL'] = 0.3
pars['EK'] = -12
pars['ENa'] = 115
pars['EL'] = 10.6
pars['C'] = 1

pars['alphan'] = lambda V: 0.01*(10 - V)/(np.exp(1 - V/10) - 1)
pars['betan'] = lambda V: 0.125 * np.exp(-V / 80)
pars['alpham'] = lambda V: 0.1*(25 - V)/(np.exp(2.5 - V/10) - 1)
pars['betam'] = lambda V: 4 * np.exp(-V / 18)
pars['alphah'] = lambda V: 0.07 * np.exp(-V / 20)
pars['betah'] = lambda V: 1 / (np.exp(3 - V/10) + 1)

# Initial conditions at equilibrium
pars['V0'] = 0
Vrest = pars['V0']
pars['n0'] = pars['alphan'](Vrest) / (pars['alphan'](Vrest) + pars['betan'](Vrest))
pars['m0'] = pars['alpham'](Vrest) / (pars['alpham'](Vrest) + pars['betam'](Vrest))
pars['h0'] = pars['alphah'](Vrest) / (pars['alphah'](Vrest) + pars['betah'](Vrest))

# Time vector
t0 = 0
tf = 20
tstep = 0.02
t = np.arange(t0, tf + tstep, tstep)
y0 = np.array([pars['V0'], pars['n0'], pars['m0'], pars['h0']])

# Sweep I_amp values
I_values = [12, 13.4, 14]

for I in I_values:
    impulse_t.I_amp = I  
    y = integrate.odeint(model_hh, y0, t, args=(pars,))
    V_trace = y[:, 0]

    # Plot
    plt.figure(figsize=(8, 4))
    plt.plot(t, V_trace, label=f'I = {I} µA/cm²', color='C0')
    plt.title(f'Hodgkin-Huxley Neuron: I = {I} µA/cm² (2–2.5 ms pulse)')
    plt.xlabel("Time (ms)")
    plt.ylabel("Membrane Voltage (mV)")
    plt.grid(True)
    plt.legend()
    plt.tight_layout()
    plt.ylim(-40,150)
    plt.show()
